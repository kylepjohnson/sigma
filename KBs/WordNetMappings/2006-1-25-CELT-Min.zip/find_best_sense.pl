% sense_score(Sense, Score) is to record the current maximal number of matches between its Context and the co-occurrence 
% data and the corresponding Sense of the Word

% celt_version(3,b,2.65).

% :- ['c:\\2004-01-05-CELTv2.65-3b\\Tools.pl'].

% cooc(Word, POS, LN, SUMO, LLC) contains the co-occurrence data (co-word and frequency) extracted from Brown Corpus.
% example: cooc(absence, 'NN', [1, 2], located, [[absence, 2], [academic, 1], [achieve, 1], [actual, 1] ..., [youth, 1]]).
% [1, 2] means the senses for noun absense are mapped to the same SUMO term located.  

:- [cooc].

:- index(cooc(1, 1, 1, 0, 0)).

% :- ['Wn_s.pl'].

% :- index(s(0, 0, 1, 1, 1, 0)).

:- dynamic sense_score/2.
:- retractall(sense_score(_, _)).

/*
%  find_synset(+Word, +POS, +Context, -Synset).
%  Context is a list of words cooccuring with the Word.  
%  For example, if the sentence to be translated is 'The window faces the street.', we have
%  find_synset('Window', n, [face, street], -Synset1)
%  find_synset(face, v, ['Window', street], -Synset2)
%  find_synset(street, n, ['Window', face], -Synset3)


find_synset(Word, POS, Context, Synset) :-
	retractall(sense_score(_, _)),
	assert(sense_score(1, 0)),
	(POS == n -> Code = 'NN' ; Code = 'VB'),
	find_best_sense(Word, Code, Context, Sense),
	s(Synset, _, Word, POS, Sense, _).
*/

%  find_synset(+Word, +POS, -Synset).
%  X in context(X) is a list of words cooccuring with the Word.  
%  For example, if the sentence to be translated is 'The window faces the street.', we have
%  find_synset('Window', n, [face, street], -Synset1)
%  find_synset(face, v, ['Window', street], -Synset2)
%  find_synset(street, n, ['Window', face], -Synset3)


find_synset(Words, POS, Synset) :-
	is_list(Words),
	convert_list_to_compound(Words, Compound), 
	context(Context),
%	delete(X, Words, Context),		% unnecessary to delete all component of the word list
	retractall(sense_score(_, _)),
	assert(sense_score(1, 0)),
	(POS == n -> Code = 'NN' ; Code = 'VB'),
	find_best_sense(Compound, Code, Context, Sense),
%	find_synset_id(Synset, Compound, POS, Sense).
	s(Synset, _, Compound, POS, Sense, _), !.
	
find_synset(Word, POS, Synset) :-
	context(X),
	delete(X, Word, Context),
	retractall(sense_score(_, _)),
	assert(sense_score(1, 0)),
	(POS == n -> Code = 'NN' ; Code = 'VB'),
	lowercase(Word, LWord),
	find_best_sense(LWord, Code, Context, Sense),
%	find_synset_id(Synset, LWord, POS, Sense).
	s(Synset, _, LWord, POS, Sense, _), !.

	
% return the sense of the word corresponding to the highest score of matching between its context and its co-occurrence data
find_best_sense(Word, Code, Context, Sense) :-
	cooc(Word, Code, [Sense|_], _, LLC),
	gather_freq(Word, Context, LLC, Freq),
	sense_score(_, Score),
	(Freq > Score -> 
	   	(retractall(sense_score(_, _)),
		 assert(sense_score(Sense, Freq))
		) ; true
	), 
	fail.
find_best_sense(_, _, _, Sense) :- sense_score(Sense, _), !.

% The input Word is a lower case single or compound word but the word in s/6 can be any of the following:
% single word lower case: 				e.g. spring
% single word with initial capital: 			e.g. Iliad
% single word all capitals: 				e.g. PM
% compound lower case: 					e.g. face_to_face
% compound with initial capital: 			e.g. French_kiss
% compound with initial capital for each component: 	e.g. Winston_Churchill
find_synset_id(Synset, Word, POS, Sense) :-
	s(Synset, _, Word, POS, Sense, _).

% this is a backup but very expensive in runtime and i'd rather not to do cooc matching with the proper_nouns
find_synset_id(Synset, Word, POS, Sense) :-
	s(Synset, _, SWord, POS, Sense, _),
	lowercase(SWord, Word).


gather_freq(_, _, [], 0).
gather_freq(_, [], _, 0).
gather_freq(Word, [Co_word|Context], LLC, Freq) :-
	gather_freq(Word, Context, LLC, Freq1), 
	(member([Co_word, F], LLC) -> 
	   	Freq is Freq1 + F ; Freq is Freq1).

% convert a list of words to a compound
convert_list_to_compound(Words, Compound) :-
	is_list(Words), !,
	lowercase_words(Words, Lowcase_words),
	concat_atom(Lowcase_words, '_', Compound).

% convert a list of words to lowcases
lowercase_words([], []).
lowercase_words([Word|List], [L|LL]) :-
	atom(Word),
	lowercase(Word, L),
	lowercase_words(List, LL).



% This is the entry of a sequence of morphological processes. (from OntMapping)
to_singular([], []).   				
to_singular([Word1 | List1], [Word2 | List2]) :-
   	to_singular_word(Word1, Word2), 
      	to_singular(List1, List2). 

% -ly is taken away to increase the chance of mapping
to_singular_word(Word1, Word2) :-   	% taking away -ly
   	atom_length(Word1, L), 
	L2 is L - 2, L2 > 0, 
        sub_atom(Word1, L2, 2, 0, ly), 
	sub_atom(Word1, 0, L2, _, Word2),  
	s(_, _, Word2, _, _, _).

to_singular_word(Word, Word) :-  		% already a singular noun
	noun_in_lexicon(Word, _, _, _, _, _, _).

% irregular forms
to_singular_word(Word1, Word2) :-  		% noun exceptions 
      	noun_exception(Word1, Word2).

to_singular_word(Word1, Word2) :-  		% adjective exceptions 
      	adjective_exception(Word1, Word2).
to_singular_word(Word1, Word2) :-  		% adverb exceptions 
      	adverb_exception(Word1, Word2).

% convert a noun to its singular form
to_singular_word(Word1, Word2) :-        	% -s     
   	atom_length(Word1, L), 
	L1 is L - 1, 
      	L1 > 0, 
      	sub_atom(Word1, L1, 1, 0, s),
	sub_atom(Word1, 0, L1, _, Word2), 
	noun_in_lexicon(Word2, _, _, _, _, _, _).

to_singular_word(Word1, Word2) :-        	% -ses -xes -zes -ches -shes drop es    
   	atom_length(Word1, L), 
	L2 is L - 2, L3 is L - 3, L4 is L - 4, L3 > 0, 
      	((sub_atom(Word1, L3, 3, 0, ses) | sub_atom(Word1, L3, 3, 0, xes) | sub_atom(Word1, L3, 3, 0, zes) | 
      	 (L4 > 0, (sub_atom(Word1, L4, 4, 0, ches) | sub_atom(Word1, L4, 4, 0, shes)))) -> 
      		   (sub_atom(Word1, 0, L2, _, Word2),  
			noun_in_lexicon(Word2, _, _, _, _, _, _))).

to_singular_word(Word1, Word2) :- to_infinitive(Word1, Word2).   % it might be a verb

to_infinitive(Word, Word) :- 			% already an infinitive
	verb_in_lexicon(_, Word, _, _, _, _, _, _). 

to_infinitive(Word1, Word2) :-  		% exceptions 
     	verb_exception(Word1, Word2).

% convert a verb to its infinitive
to_infinitive(Word1, Word2) :-        		% -ies -> y
   	atom_length(Word1, L), 
	L3 is L - 3, L3 > 0, 
      	(sub_atom(Word1, L3, 3, 0, ies) -> 
        	(sub_atom(Word1, 0, L3, _, X),  
		 atom_concat(X, y, Word2),
		 verb_in_lexicon(_, Word2, _, _, _, _, _, _))).

to_infinitive(Word1, Word2) :-        		% -es, -ed -> e, or -> NULL
   	atom_length(Word1, L), 
	L2 is L - 2, L1 is L -1, L2 > 0, 
        ((sub_atom(Word1, L2, 2, 0, es) | sub_atom(Word1, L2, 2, 0, ed)) -> 
               	((sub_atom(Word1, 0, L1, _, Word2) |  sub_atom(Word1, 0, L2, _, Word2)), 
               	  verb_in_lexicon(_, Word2, _, _, _, _, _, _))).

to_infinitive(Word1, Word2) :-        		% -s     
   	atom_length(Word1, L), 
	L1 is L - 1, 
      	L1 > 0, 
      	sub_atom(Word1, L1, 1, 0, s),
	sub_atom(Word1, 0, L1, _, Word2), 
	verb_in_lexicon(_, Word2, _, _, _, _, _, _).

to_infinitive(Word1, Word2) :-        		% -ing -> e, or -> NULL
   	atom_length(Word1, L), 
	L3 is L - 3, L3 > 0, 
      	(sub_atom(Word1, L3, 3, 0, ing) -> 
        	((sub_atom(Word1, 0, L3, _, X),  
		  concat_atom([X, e], Word2),
		  verb_sumo(Word2, _, _, _)) |
                 (sub_atom(Word1, 0, L3, _, Word2),  
		  verb_in_lexicon(_, Word2, _, _, _, _, _, _)))).

% not a noun nor a verb
to_infinitive(Word, Word). 

