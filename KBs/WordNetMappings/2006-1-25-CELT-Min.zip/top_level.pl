% CELT interface to automatic theorem provers

% Copyright � 2003 Teknowledge Corporation
% This software released under the GNU Public License <http://www.gnu.org/copyleft/gpl.html>.

% William R. Murray

% Defines these CELT top-level functions
% providing single-sentence capabilties:
%	  single_sentence_eng2log/1
%         xml_single_sentence_eng2log/2
% and these providing DRS capabilities:
%	  top_level/0
%	  eng2log/1
%	  xml_eng2log/2

:- style_check(-singleton).      % no singletons warnings
:- style_check(-discontiguous).  % allows more creative predicate placement

:-write_herald(', top-level calling functions to invoke CELT.').

%----------------------------------
%    CELT top-level functions
%----------------------------------

% These are top-level functions used to invoke CELT originally just from SWI-Prolog for
% single sentences, and then later for multiple sentences with DRS capabilities and from
% over a socket connection. Originally these were dispersed in several different files and
% then brought together finally.

%-------------------------------
% Original code for single-sentence
% Capabilities...
%-------------------------------

% NOTES on top-level interfaces: the original interface was called eng2log and just
% handled single sentences. When the ability to handle multiple sentences was added
% the old eng2log was renamed single_sentence_eng2log and new interface (called from
% the top-level as celt/0) was aliased as eng2log so that Sigma integration code would
% not have to be changed. The old top_level/0 loop used to call the single sentence
% version.

% single_sentence_eng2log(+Sentence)
% prints out the parse of the sentence given and then the SUMO clauses it generates.
% Sentence is a a list of char codes and can be given as

single_sentence_eng2log(Sentence) :-
  preprocess_and_parse(Sentence,Features,KindOfSentence),
  !,                                                 % if parse succeeds but logic fails do not back up and parse again
  traverse_features_and_return_existential(KindOfSentence,Features,SUO,SPEECH_ACT,SUBS), % now translate semantic features to logic
  nl,write('Translation to Logic:'),nl,
  pretty_print(SUO),nl,nl,
  % There is no need for the next simplification as it always already occurs in traverse_features_and_return_existential...
  % simplify_to_canonical_form(SUO,Simplified_SUMO_Forms),
  % pretty_print(SUO),nl,nl,
  pretty_print_to_string(SUO,yes,Translation),
  write(Translation),nl,
  (theorem_prover_connected -> ask_query_or_make_assertion(Sentence,SUO,Translation,KindOfSentence,SPEECH_ACT,Result); true),
  describe_speech_act(SPEECH_ACT),
  gather_translation_warnings(KindOfSentence,Features,Translation_Warnings),
  write_numbered_list(Translation_Warnings),
  (theorem_prover_connected -> (generate_reply(Sentence,Features,SUBS,SPEECH_ACT,Result,Reply),writeln(Reply)); true).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  JL: To use co-occurrence data for identifying senses, the whole input needs to be used. It's better to 
%      save it as a dynamic record so it can be picked up anywhere is the parsing
%  context(Word_List) serves this purpose and needs to be used to store the context when the sentence is 
%  	converted into a list of words.  Note the context is just for one single sentence. To denote multiple 
%       sentences, it needs to be called at a higher level.
%  store_context/1 is used to clean the word list and store it in the memory
%       It is called in preprocess_and_parse/3 after the morphological processing and before the feature 
%       is processed.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

:- dynamic context/1.
:- retractall(context(_)).

store_context(Word) :-
	remove_stopword(Word, WL),
	to_singular(WL, Root),
	retractall(context(_)),
	assert(context(Root)).

% remove_stopword(+Inlist, -OutList). OutList is the remaining InList with no stop words in it.
remove_stopword([], []). 
remove_stopword([Word | List1], List2) :-  		

	% a reduced WordNet stoplist (<199) 
	member(Word, ['I',a,all,although,amid,amidst,an,and,another,any,anybody,anyone,anything,as,astride,aught,bar,barring,
because,both,but,circa,concerning,considering,despite,each,either,everybody,everyone,few,fewer,has,had,have,he,her,hers,herself,him,
himself,his,hisself,idem,if,ilk,it,its,itself,many,me,mine,most,myself,naught,neither,nobody,none,nor,nothing,
notwithstanding,of,oneself,or,other,otherwise,our,ourself,ourselves,pending,per,plus,regarding,save,self,several,she,
since,so,some,somebody,someone,something,somewhat,such,suchlike,sundry,than,that,the,thee,theirs,them,themselves,there,
they,thine,this,thou,though,thyself,tother,twain,unless,upon,us,various,versus,via,vis-a-vis,we,what,whatall,whatever,
whatsoever,when,whereas,wherewith,wherewithal,which,whichever,whichsoever,while,who,whoever,whom,whomever,whomso,whomsoever,
whose,whosoever,ye,yet,yon,yonder,you,you-all,yours,yourself,yourselves]),
	remove_stopword(List1, List2).
remove_stopword([Word | List1], [Word | List2]) :-  		
	remove_stopword(List1, List2).	



% preprocess_and_parse(+Sentence,-Features,-KindOfSentence)
% preprocess_and_parse converts a sentence in string form (a list of
% character codes) into a list of words and then performs a preliminary
% preprocessing on the words prior to parsing. The preprocessing detects
% word variants that are not in CELT and maps them onto CELT where possible
% (e.g., 'eaten' -> 'eats', 'chickens' -> 'chicken', etc). After preprocessing
% the revised sentence (list of words) is parsed and a grammatical feature
% structure is built for the sentence or query parse.
%
% JL: store_context/1 is added to store the context information.


preprocess_and_parse(Sentence,Features,KindOfSentence) :-
  drop_trailing_white_space(Sentence,Trimmed_Sentence),
  sentenceToList(Trimmed_Sentence,Words_In,KindOfSentence),  % convert Sentence, a string, to list and note kind of sentence
  check_sentence_words(KindOfSentence,               % pass along the kind of sentence for morphological processing of words:
		       Words_In,                     % check_sentence_words drops first word to lowercase if necessary, it also
		       Words_Out,                    % maps words not in base form to base form and generates preprocessor warnings, too
		       Lexical_Warnings),            % all preprocessor, not in lexicon, wrong base form, etc.  warnings are returned here
  print_preprocessor_results(Words_In,Words_Out,Lexical_Warnings),
  store_context(Words_Out),			     % JL: to save the context for the matching
  !,                                                 % if parse fails do not back up past here
  ((KindOfSentence == sentence) -> phrase(sentence(Features),Words_Out); phrase(query(Features),Words_Out)),
  nl,nl,write('Parsed '),write(KindOfSentence),write(' OK:'),write_sent(Words_Out),nl,
  display_feature_structure(Features).


% print_preprocessor_results(+Words_In,+Words_Out,+Lexical_Warnings)
% prints the results of CELT's preprocessing to detect words not in lexicon
% and to coerce words to their proper form when they are in the lexicon but
% are not the right tense, plurality, or capitalization.

print_preprocessor_results(Words_In,Words_Out,Lexical_Warnings) :-
  print_stars,
  ((Words_In == Words_Out) ->
      format("CELT preprocessing: No changes to the input sentence.~n");
      format("CELT preprocessing: The input sentence has been changed.~n"),
      format("~nGiven: "),write_sent(Words_In),
      format("~nRewrite: "),write_sent(Words_Out)),
  ((Lexical_Warnings == []) ->
      format("~nNo lexical errors or abbreviations found in preprocessing.~n");
      format("~nLexical Errors or abbreviations found in preprocessing:~n"),
      write_numbered_list(Lexical_Warnings)),
  print_stars.

% xml_single_sentence_eng2log(+Sentence,-XML_String)
% is like single_sentence_eng2log/1 except that:

% 1. It prints its output to a single string which
% can be XML parsed to separate out its various parts: the translation, the kind of speech act,
% and the lexical warnings. This version of xml_single_sentence_eng2log is used for an interface to Sigma
% that can be called under Java. It returns only one argument that Java can then parse with XML.

% 2. If the parse would fail because of a word not being in the lexicon then single_sentence_eng2log would
% return fail. Instead, xml_single_sentence_eng2log returns the the preprocessor warnings and the rest of
% the XML tags are empty.

% <translation>
% <preprocessor_warnings>
% </preprocessor_warnings>
% <parse>
% </parse>
% <KIF>
% </KIF>
% <translation_warnings>
% </translation_warnings>
% <kind_of_speech_act>
% </kind_of_speech_act>
% <reply_template>
% </reply_template>
% </translation>

xml_single_sentence_eng2log(Sentence,XML_String) :-
  sformat(Start_Translation_Tag,'~n<translation>'),
  xml_preprocess_and_parse_single_sentence(Sentence,Features,KindOfSentence,Lexical_Warnings),
  sformat(Start_Preprocessor_Warning_Tag,'~n<preprocessor_warnings>'),
  write_numbered_list2(Lexical_Warnings,List_Of_Preprocessor_Warnings),
  sformat(End_Preprocessor_Warning_Tag,'</preprocessor_warnings>'),
  !,                                                 % if parse succeeds but logic fails do not back up and parse again
  traverse_features_and_return_existential(KindOfSentence,Features,SUO,SPEECH_ACT,SUBS), % now translate semantic features to logic
  sformat(Start_KIF_Tag,'~n<KIF>'),
  % There is no need for the next simplification as it always already occurs in traverse_features_and_return_existential...
  % simplify_to_canonical_form(SUO,Simplified_SUMO_Forms),
  pretty_print_to_string(SUO,yes,Translation),
  sformat(End_KIF_Tag,'~n</KIF>~n'),
  (theorem_prover_connected -> ask_query_or_make_assertion(Sentence,SUO,Translation,KindOfSentence,SPEECH_ACT,Result); true),
  sformat(Start_Speech_Act_Tag,'~n<kind_of_speech_act>~n'),
  describe_speech_act(SPEECH_ACT,KindOfSpeechAct),
  sformat(End_Speech_Act_Tag,'</kind_of_speech_act>~n'),
  sformat(Start_Translation_Warnings_Tag,'~n<translation_warnings>'),
  gather_translation_warnings(KindOfSentence,Features,Translation_Warnings),
  write_numbered_list2(Translation_Warnings,List_Of_Translation_Warnings),
  sformat(End_Translation_Warnings_Tag,'</translation_warnings>'),
  sformat(Start_Reply_Template_Tag,'~n<reply_template>~n'),
  (theorem_prover_connected ->
      (generate_reply(Sentence,Features,SUBS,SPEECH_ACT,Result,Reply_To_Use),
	  writeln(Reply_To_Use),
	  write_sentence_words(Reply_To_Use,Reply_Out));
      Reply_Out = 'Prolog query reasoner not connected.'),
  sformat(End_Reply_Template_Tag,'</reply_template>~n'),
  sformat(End_Translation_Tag,'</translation>~n'),
  sformat(XML_String,'~a~n~a~w~a~n~a~a~a~n~a~a~a~n~a~w~a~n~a~a~a~a',
	  [Start_Translation_Tag,
	   Start_Preprocessor_Warning_Tag,List_Of_Preprocessor_Warnings,End_Preprocessor_Warning_Tag,
	   Start_KIF_Tag,Translation,End_KIF_Tag,
	   Start_Speech_Act_Tag,KindOfSpeechAct,End_Speech_Act_Tag,
	   Start_Translation_Warnings_Tag,List_Of_Translation_Warnings,End_Translation_Warnings_Tag,
	   Start_Reply_Template_Tag,Reply_Out,End_Reply_Template_Tag,
	   End_Translation_Tag]),
  !.

% Handle case where there are lexical errors, in particular a word not in the lexicon,
% which leads to a parse failure. We want to return the word not in lexicon error message
% rather than have xml_single_sentence_eng2log/2 fail completely. So we check that the results
% from xml_preprocess_and_parse_single_sentence/4 would be that Lexical_Warnings would be returned
% but the function would fail due to a parse failure by open-coding it below.

xml_single_sentence_eng2log(Sentence,XML_String) :-
  sformat(Start_Translation_Tag,'~n<translation>'),
  % begin open code for...xml_preprocess_and_parse_single_sentence(Sentence,Features,KindOfSentence,Lexical_Warnings)

  sentenceToList(Sentence,Words_In,KindOfSentence),  % convert Sentence, a string, to list and note kind of sentence
  check_sentence_words(KindOfSentence,               % pass along the kind of sentence for morphological processing of words:
		       Words_In,                     % check_sentence_words drops first word to lowercase if necessary, it also
		       Words_Out,                    % maps words not in base form to base form and generates preprocessor warnings, too
		       Lexical_Warnings),            % all preprocessor, not in lexicon, wrong base form, etc.  warnings are returned here

  % check parse indeed fails...perhaps we don't really need to do this and could save time here...
  not((KindOfSentence == sentence) -> phrase(sentence(Features),Words_Out); phrase(query(Features),Words_Out)),

  % end open code for...xml_preprocess_and_parse_single_sentence(Sentence,Features,KindOfSentence,Lexical_Warnings)

  sformat(Start_Preprocessor_Warning_Tag,'~n<preprocessor_warnings>'),
  write_numbered_list2(Lexical_Warnings,List_Of_Preprocessor_Warnings),
  sformat(End_Preprocessor_Warning_Tag,'</preprocessor_warnings>'),
  sformat(Start_KIF_Tag,'~n<KIF>'),
  Translation = 'No Translation.',
  sformat(End_KIF_Tag,'~n</KIF>~n'),
  sformat(Start_Speech_Act_Tag,'~n<kind_of_speech_act>~n'),
  KindOfSpeechAct = KindOfSentence,
  sformat(End_Speech_Act_Tag,'</kind_of_speech_act>~n'),
  sformat(Start_Translation_Warnings_Tag,'~n<translation_warnings>'),
  List_Of_Translation_Warnings = ' ',
  sformat(End_Translation_Warnings_Tag,'</translation_warnings>'),
  sformat(Start_Reply_Template_Tag,'~n<reply_template>~n'),
  Reply_Out = 'No Reply.',
  sformat(End_Reply_Template_Tag,'</reply_template>~n'),
  sformat(End_Translation_Tag,'</translation>~n'),
  sformat(XML_String,'~a~n~a~w~a~n~a~a~a~n~a~a~a~n~a~w~a~n~a~a~a~a',
	  [Start_Translation_Tag,
	   Start_Preprocessor_Warning_Tag,List_Of_Preprocessor_Warnings,End_Preprocessor_Warning_Tag,
	   Start_KIF_Tag,Translation,End_KIF_Tag,
	   Start_Speech_Act_Tag,KindOfSpeechAct,End_Speech_Act_Tag,
	   Start_Translation_Warnings_Tag,List_Of_Translation_Warnings,End_Translation_Warnings_Tag,
	   Start_Reply_Template_Tag,Reply_Out,End_Reply_Template_Tag,
	   End_Translation_Tag]).

% Finally we should never reach this case, but you know how software is, so let's cover all bases...

xml_single_sentence_eng2log(Sentence,XML_String) :-
  sformat(Start_Translation_Tag,'~n<translation>'),
  sformat(Start_Preprocessor_Warning_Tag,'~n<preprocessor_warnings>'),
  List_Of_Preprocessor_Warnings = ' ',
  sformat(End_Preprocessor_Warning_Tag,'</preprocessor_warnings>'),
  sformat(Start_KIF_Tag,'~n<KIF>'),
  Translation = 'No Translation.',
  sformat(End_KIF_Tag,'~n</KIF>~n'),
  sformat(Start_Speech_Act_Tag,'~n<kind_of_speech_act>~n'),
  KindOfSpeechAct = 'Could not determine.',
  sformat(End_Speech_Act_Tag,'</kind_of_speech_act>~n'),
  sformat(Start_Translation_Warnings_Tag,'~n<translation_warnings>'),
  List_Of_Translation_Warnings = ' ',
  sformat(End_Translation_Warnings_Tag,'</translation_warnings>'),
  sformat(Start_Reply_Template_Tag,'~n<reply_template>~n'),
  Reply_Out = 'No Reply.',
  sformat(End_Reply_Template_Tag,'</reply_template>~n'),
  sformat(End_Translation_Tag,'</translation>~n'),
  sformat(XML_String,'~a~n~a~w~a~n~a~a~a~n~a~a~a~n~a~w~a~n~a~a~a~a',
	  [Start_Translation_Tag,
	   Start_Preprocessor_Warning_Tag,List_Of_Preprocessor_Warnings,End_Preprocessor_Warning_Tag,
	   Start_KIF_Tag,Translation,End_KIF_Tag,
	   Start_Speech_Act_Tag,KindOfSpeechAct,End_Speech_Act_Tag,
	   Start_Translation_Warnings_Tag,List_Of_Translation_Warnings,End_Translation_Warnings_Tag,
	   Start_Reply_Template_Tag,Reply_Out,End_Reply_Template_Tag,
	   End_Translation_Tag]).

% xml_preprocess_and_parse_single_sentence(+Sentence,-Features,-KindOfSentence)
% xml_preprocess_and_parse_single_sentence   converts a sentence in string form (a list of
% character codes) into a list of words and then performs a preliminary
% preprocessing on the words prior to parsing. The preprocessing detects
% word variants that are not in CELT and maps them onto CELT where possible
% (e.g., 'eaten' -> 'eats', 'chickens' -> 'chicken', etc). After preprocessing
% the revised sentence (list of words) is parsed and a grammatical feature
% structure is built for the sentence or query parse.

% This version is like preprocess_and_parse but adds XML tags around output.

xml_preprocess_and_parse_single_sentence(Sentence,Features,KindOfSentence,Lexical_Warnings) :-
  sentenceToList(Sentence,Words_In,KindOfSentence),  % convert Sentence, a string, to list and note kind of sentence
  check_sentence_words(KindOfSentence,               % pass along the kind of sentence for morphological processing of words:
		       Words_In,                     % check_sentence_words drops first word to lowercase if necessary, it also
		       Words_Out,                    % maps words not in base form to base form and generates preprocessor warnings, too
		       Lexical_Warnings),            % all preprocessor, not in lexicon, wrong base form, etc.  warnings are returned here
  % format('~n<preprocessor_warnings>'),
  % print_preprocessor_results(Words_In,Words_Out,Lexical_Warnings),
  % format('</preprocessor_warnings>'),
  !,                                                 % if parse fails do not back up past here
  ((KindOfSentence == sentence) -> phrase(sentence(Features),Words_Out); phrase(query(Features),Words_Out)).

  % format('~n<parse>'),
  % nl,nl,write('Parsed '),write(KindOfSentence),write(' OK:'),write_sent(Words_Out),nl,
  % display_feature_structure(Features),
  % format('</parse>~n').

%-------------------------------
% DRS-enabled code for multi-sentence
% Capabilities...
%-------------------------------


% TOP-LEVEL READ-TRANSLATE LOOP FOR MULTIPLE SENTENCES

top_level :-
	write('Enter one or more sentences, ending each with a period and following the last with a carriage return.'),nl,
	write('Or you can enter a single question, ending with a question mark and followed by a carriage return.'),nl,
        write('Your input can span multiple lines. Exit the loop by entering ''quit.''. You can '),nl,
        write('also find out if words are in the lexicon and what part of speech they are by typing the word then a period.'),nl,
        !,
	top_level_loop_for_celt.

top_level_loop_for_celt :- repeat,write('>>'),read_multiple_sentences([],InputCharCodes),process_multiple_sentence_input(InputCharCodes).

process_multiple_sentence_input(SentenceCharCodes) :-
	sentenceToList(SentenceCharCodes,[Word],sentence),        % Was the input only a single word? (command or lexicon lookup)
	!,
	handle_command_word_or_lexicon_lookup(Word).

handle_command_word_or_lexicon_lookup(Word) :-                    % Succeed (and thus stop the top-level loop) for a 'quit'
	memberchk(Word,[quit,bye,halt,stop,abort]),
	writeln('Goodbye').

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'postedit'. Fail reinvokes the top-level loop.
	memberchk(Word,[postedit]),
	catch(post_edit,abort_answer_entry(X),format('Returning to top-level CELT.~n')),
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'noun'. The fail reinvokes the top-level loop.
	memberchk(Word,[noun]),
	catch(define_new_noun_for_lexicon,abort_answer_entry(X),format('Returning to top-level CELT.~n')),
	!,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle command: 'abbrev'. The fail reinvokes the top-level loop.
	memberchk(Word,[abbrev,abbreviation]),
	catch(define_new_abbreviation,abort_answer_entry(X),format('Returning to top-level CELT.~n')),
	!,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'verb'. The fail reinvokes the top-level loop.
	memberchk(Word,[verb]),
	catch(define_new_verb_for_lexicon,abort_answer_entry(X),format('Returning to top-level CELT.~n')),
	!,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'adjective'. Fail reinvokes top-level loop.
	memberchk(Word,[adjective,adj]),
	catch(define_new_adjective_for_lexicon,abort_answer_entry(X),format('Returning to top-level CELT.~n')),
	!,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'adverb'. Fail reinvokes top-level loop.
	memberchk(Word,[adverb,adv]),
	catch(define_new_adverb_for_lexicon,abort_answer_entry(X),format('Returning to top-level CELT.~n')),
	!,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'save'. Fail reinvokes top-level loop.
	memberchk(Word,[save]),
	save_new_lexicon,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'load'. Fail reinvokes top-level loop.
	memberchk(Word,[load]),
	load_new_lexicon,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'redo'. 
	memberchk(Word,[redo]),
	restore_char_codes(SentenceCharCodes),                    % Reuse input from last sentences or query.
	format('Redoing...~n~s',[SentenceCharCodes]),
	nl,eng2log(SentenceCharCodes),!,                          
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'help'. The fail reinvokes the top-level loop.
	memberchk(Word,[help]),
        help_celt_commands,
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'examples'. 
	memberchk(Word,[examples]),
        show_sample_celt_sentences,
        show_sample_celt_queries,	
	fail.

handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'nonexamples'. 
	memberchk(Word,[nonexamples]),
        show_sample_celt_sentence_near_misses,
        show_sample_celt_query_near_misses,	
	fail.

help_celt_commands :-
	write('These single word commands are recognized:'),
	nl,
	write(' quit   -- quits the CELT command loop, returning to Prolog\'s command loop.'),
	nl,
        write(' help   -- prints out this help.'),
	nl,
        write(' kb     -- toggles off input of translated sentences as assertions and use of translated questions as queries to the KB.'),
	nl,
        write(' listing -- list kb facts.'),
	nl,	
	write(' postedit -- allows you to specify that one word sense of a noun or verb should take precedence over others.'),
	nl,
	write(' redo -- allows you to redo the last translation.'),
	nl,	
	write(' noun -- add a new noun.'),
	nl,
	write(' verb -- add a new verb.'),
	nl,
	write(' adjective -- add a new adjective.'),
	nl,
	write(' adverb -- add a new adverb.'),
	nl,				
	write(' examples -- show typical examples of acceptable CELT sentences and queries to try'),
	nl,
	write(' nonexamples -- shows typical examples of input CELT cannot handle and explains why'),
	nl,	
	write('All other sequences of words ending in sentence or question delimiters are interpreted as assertions or queries to translate.'),
	nl,
	write('Finally, all other individual words followed by a period are looked up against the lexicon.'),
	nl,
        !.

show_sample_celt_sentence_near_misses :-
	write('SAMPLES OF SENTENCE INPUT THAT CELT CANNOT TRANSLATE:'),
	nl,nl,
	format("John always runs.[Cannot use modals like 'always', 'can', 'should', 'may', 'might', 'possibly', etc.]"),
	nl,
	write('Certainly, John sees the cat. [Cannot use sentence modifiers.]'),
	nl,	
	write('Certainly! John--a great hunter--sees the cat.'),nl,
	format("[Syntax and syntactic constructions involving more sophisticated punctuation (!,-,;,&,...,etc.) not handled]"),
	nl,	
        write('John kicks the bucket. He should have served the Ford first. [Cannot handle cliches, metaphors, or metanomy] '),
	nl,
        write('Most of the hummingbirds attacked the feeder. [Cannot handle plurals and plural quantifiers]'),
	nl,
	format("John ate a sandwich. [Cannot handle past tense unless morphy flag is on]"),
	nl,
        !.

show_sample_celt_queries :-
	write('SAMPLES OF QUERY INPUT THAT CELT TRANSLATES:'),
	nl,nl,
	write('Who runs?'),
	nl,
	write('Who sees the feline?'),
	nl,	
        write('What does Mary give to John?'),
	nl,
        write('Who is the baker?'),
	nl,
        !.

show_sample_celt_sentences :-
	write('SAMPLES OF SENTENCE INPUT THAT CELT TRANSLATES:'),
	nl,nl,
	write('John runs.'),
	nl,
	write('John walks to the river. He sees the cat.'),
	nl,	
        write('Mary gives the book to John.'),
	nl,
        write('The priest that sees the aardvark is the baker.'),
	nl,
	format("John's customer enters the bank that Mary walks into."),
	nl,
        !.

show_sample_celt_query_near_misses :-
	write('SAMPLES OF QUERY INPUT THAT CELT CANNOT TRANSLATES:'),
	nl,nl,
	format("Why is the door open? [CELT does not handle 'why' questions without special domain-specific programming]"),
	nl,
	write('Would there be a person who could do it? [CELT does not handle queries that are counterfactual or involving modals]'),
	nl,	
        !.

% Toggling use of the knowledge-base.
handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'kb'. The fail reinvokes the top-level loop.
	memberchk(Word,[kb]),
        format("Toggle knowledge-base connection.~n"),
	(toggle_embedded_prover->
	   format("Future assertions and queries will use the KB.~n");
	   format("Future assertions and queries will NOT use the KB.~n")),
	fail.

% Listing the contents of the knowledge base.
handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'listing'. 
	memberchk(Word,[listing]),
	show_clauses,
	fail.

% Resetting the knowledge base.
handle_command_word_or_lexicon_lookup(Word) :-                    % Handle one-word command: 'eraseKB'. 
	memberchk(Word,[eraseKB]),
	remove_added_clauses,
        format("Knowledge-base cleared. Future assertions and queries will use the newly cleared KB.~n"),
	fail.

% Looking up a work in the lexicon.
handle_command_word_or_lexicon_lookup(Word) :-                    % Otherwise lookup the word in the lexicon but continue.
	lookup_word_in_lexicon(Word),
	fail.

process_multiple_sentence_input(SentenceCharCodes) :-
	save_char_codes(SentenceCharCodes),                        % To allow REDO command to work.
	nl,eng2log(SentenceCharCodes),!,fail.                      % Intentionally fail to reinvoke the top-level loop's repeat.

process_multiple_sentence_input(SentenceCharCodes) :- write('Sorry, but the parse fails on that input.'),nl,fail. 

eng2log(Input) :-
	atom(Input),name(Input,InputCharCodes),!,eng2log(InputCharCodes).

eng2log(Input) :-
	not(is_list(Input)),!,
	!,
	format("Input to eng2log should be a string, not an atom or anything else, such as: ~w~n",[Input]),
	fail.

% Hand off negated sentences to single_sentence_eng2log, the older interface that handles individual sentences and questions
% by parsing and without DRSes.  We don't handle negations in multiple sentences, with anaphoric references, with quantifiers,
% or in queries at  this time.

eng2log(InputCharCodes) :-
	drop_trailing_white_space_in_list_of_chars(InputCharCodes,TrimmedCharCodes),
	sentenceToList(TrimmedCharCodes,FinalListOfTokens,sentence),
	append(First,[does,not|Last],FinalListOfTokens),     % search for 'does not' in the list of tokens
	separate_sentences(TrimmedCharCodes,ListOfSentences),
	length(ListOfSentences,1),
	!,
	single_sentence_eng2log(TrimmedCharCodes).

% Hand off individual questions to single_sentence_eng2log, the older interface that handles individual sentences and questions
% by parsing and without DRSes.  We don't handle questions intermixed in multiple sentences as it is not clear what they would
% mean.	

eng2log(InputCharCodes) :-
	drop_trailing_white_space_in_list_of_chars(InputCharCodes,TrimmedCharCodes),
	sentenceToList(TrimmedCharCodes,FinalListOfTokens,SentenceOrQuery),
	separate_sentences(TrimmedCharCodes,ListOfSentences),
	length(ListOfSentences,1),
	does_not_need_DRS(FinalListOfTokens),
	!,
	single_sentence_eng2log(TrimmedCharCodes).

% We do handle multiple or individual sentences.
eng2log(InputCharCodes) :-
	drop_trailing_white_space_in_list_of_chars(InputCharCodes,TrimmedCharCodes),
	translate_one_or_more_sentence_with_DRS(TrimmedCharCodes).

% translate_one_or_more_sentence_with_DRS(+Input_String) takes
% one or more sentences in the input string list of char codes
% and enters them into DRSes, runs DRS reduction rules, resolves
% anaphoric references, and then generates code from the DRSes.

translate_one_or_more_sentence_with_DRS(Input_String) :-
	translate_one_or_more_sentence_with_DRS(Input_String,_).

% translate_one_or_more_sentence_with_DRS(+Input_String,-SUMO_Forms) takes
% one or more sentences in the input string list of char codes
% and enters them into DRSes, runs DRS reduction rules, resolves
% anaphoric references, and then generates code from the DRSes
% and returns this for optional use as SUMO_Forms. It is used, e.g.,
% when comparing DRS test translations against pre-stored results.

translate_one_or_more_sentence_with_DRS(Input_String,SUMO_Forms) :-
	clear_relevant_DRSes,
	count_DRSes, % counts and warns of DRSes not properly cleared away, a fail-safe measure.
	reset_all_generated_names,
	separate_sentences(Input_String,List_Of_Sentences),	
	create_top_DRS(Generated_Name),
	add_sentences_to_DRS(Generated_Name,List_Of_Sentences),
	drt_message_format('~nDRSes created from input OK.~n'),
	!, % If sentence and DRS reductions fail do not back up beyond here.
	reduce_conditions_DRS(Generated_Name,Reductions),
	Reductions \== [], % Check that at least one reduction was applied. If none were then a parse failure most likely occurred.
	drt_message_format('DRT reduction rules applied OK.~n'),
	get_relevant_DRS_names(DRSes),
	drt_write_numbered_list(DRSes),
	!, % If adding DRSes
	gather_anaphoric_referents_for_each_DRS(DRSes),
	drt_message_format('Discourse references gathered OK.~n'),
	!, % If anaphoric referent resolution fails do not back up beyond here.
	resolve_anaphoric_referents_for_each_DRS(DRSes),
	drt_message_format('Anaphoric references resolved OK.~n'),
	!, % If code generation fails do not back up beyond here.
	generate_code_for_DRS(Generated_Name,add_quantifiers,SUMO_Forms),
	drt_message_format('Code generated OK.~n'),
	simplify_to_canonical_form(SUMO_Forms,Simplified_SUMO_Forms),
	drt_message_format('Code written to canonical form OK.~n'),
	format("~nCode generated:~n"),
	pretty_print_to_string(Simplified_SUMO_Forms,yes,Translation),
	write(Translation),nl,
	(theorem_prover_connected ->
	    ask_query_or_make_assertion(Input_String,Simplified_SUMO_Forms,Translation,sentence,assertion,Result);
	    true),
	gather_translation_warnings_for_DRSes(DRSes,Translation_Warnings),
	drt_message_format('Translation warnings gathered OK.~n'),
	write_numbered_list(Translation_Warnings),
	drt_message_format("~nALL DRS processing completed OK for '~s'.~n",[Input_String]),
	!.

% celt(translate,+SENTENCE,-CELT_Output)
% is an adapter function for is the top-level server direct command called by the GUI over the
% socket server that accepts CELT commands directly. This command operates just like eng2log/1,
% except the output is captured as a string and separated by XML tags.

celt(translate,SENTENCE,CELT_Output) :-
	xml_eng2log(SENTENCE,CELT_Output).

% xml_eng2log(+Sentence,-XML_String)
% is like eng2log/1 except that it prints its output to a single string which
% can be XML parsed to separate out its various parts: the translation, the kind of speech act,
% and the lexical warnings. This version of xml_eng2log is used for an interface to Sigma
% that can be called under Java. It returns only one argument that Java can then parse with XML.

% <translation>
% <parse>
% </parse>
% <KIF>
% </KIF>
% <translation_warnings>
% </translation_warnings>
% </translation>

xml_eng2log(Input,XML_String) :-
	atom(Input),
	!,
	name(Input,InputCharCodes),
	format("Given this input, an atom: '~w', converting to a list of input characters.",[Input]),
	xml_eng2log(InputCharCodes,XML_String).

xml_eng2log(Input,XML_String) :-
	string(Input),
	!,
	string_to_list(Input,InputCharCodes),
	format("Given this input, an internal string data type: '~s', converting to a list of input characters.",[Input]),
	xml_eng2log(InputCharCodes,XML_String).

% Hand off negated sentences to single_sentence_eng2log, the older interface that handles individual sentences and questions
% by parsing and without DRSes.  We don't handle negations in multiple sentences, with anaphoric references, with quantifiers,
% or in queries at  this time.

xml_eng2log(InputCharCodes,XML_String) :-
	drop_trailing_white_space_in_list_of_chars(InputCharCodes,TrimmedCharCodes),
	sentenceToList(TrimmedCharCodes,FinalListOfTokens,sentence),
	append(First,[does,not|Last],FinalListOfTokens),     % search for 'does not' in the list of tokens
	separate_sentences(TrimmedCharCodes,ListOfSentences),
	length(ListOfSentences,1),
	!,
	xml_single_sentence_eng2log(TrimmedCharCodes,XML_String).

% Hand off individual questions to single_sentence_eng2log, the older interface that handles individual sentences and questions
% by parsing and without DRSes.  We don't handle questions intermixed in multiple sentences as it is not clear what they would
% mean.	
xml_eng2log(InputCharCodes,XML_String) :-
	drop_trailing_white_space_in_list_of_chars(InputCharCodes,TrimmedCharCodes),
	string_list_of_chars(TrimmedCharCodes),
	format("Given this input, a list of chars, checking to see if it is a query: '~s'.",[TrimmedCharCodes]),
	sentenceToList(TrimmedCharCodes,FinalListOfTokens,SentenceOrQuery),
	separate_sentences(TrimmedCharCodes,ListOfSentences),
	length(ListOfSentences,1),
	does_not_need_DRS(FinalListOfTokens),
	!,
	xml_single_sentence_eng2log(TrimmedCharCodes,XML_String).

% We do handle multiple or individual sentences.
xml_eng2log(InputCharCodes,XML_String) :-
	drop_trailing_white_space_in_list_of_chars(InputCharCodes,TrimmedCharCodes),
	string_list_of_chars(TrimmedCharCodes),
	format("Given this non-query input, a list of chars, now handling as one or more sentences: '~s'.",[TrimmedCharCodes]),
	!,
	xml_translate_one_or_more_sentence_with_DRS(InputCharCodes,XML_String).

xml_eng2log(Input,'<translation>none</translation>') :-
	format("Input to xml_eng2log should be a string or a list of character codes, not an atom or anything else, such as: ~w.~n",
	       [Input]).

% xml_translate_one_or_more_sentence_with_DRS(+Input_String) takes
% one or more sentences in the input string list of char codes
% and enters them into DRSes, runs DRS reduction rules, resolves
% anaphoric references, and then generates code from the DRSes.
% It also wraps output in XML tags and places it in a string, to
% allow Sigma to interface to CELT more easily.

xml_translate_one_or_more_sentence_with_DRS(Input_String,XML_String) :-
	sformat(Start_Translation_Tag,'~n<translation>'),
	clear_all_DRS,
	reset_all_generated_names,
	separate_sentences(Input_String,List_Of_Sentences),	
	create_top_DRS(Generated_Name),
	add_sentences_to_DRS(Generated_Name,List_Of_Sentences),
	drt_message_format('DRSes created from input OK.~n'),
	reduce_conditions_DRS(Generated_Name,Reductions_Applied),
	Reductions_Applied \==[], % If no reductions occurred then typically a parse failure happened.
	drt_message_format('DRT reduction rules applied OK.~n'),
	get_DRS_names(DRSes),
	drt_write_numbered_list(DRSes),
	!, % If adding DRSes
	gather_anaphoric_referents_for_each_DRS(DRSes),
	drt_message_format('Discourse references gathered OK.~n'),
	!, % If anaphoric referent resolution fails do not back up beyond here.
	resolve_anaphoric_referents_for_each_DRS(DRSes),
	drt_message_format('Anaphoric references resolved OK.~n'),
	!, % If code generation fails do not back up beyond here.
	generate_code_for_DRS(Generated_Name,add_quantifiers,SUMO_Forms),
	drt_message_format('Code generated OK.~n'),
	simplify_to_canonical_form(SUMO_Forms,Simplified_SUMO_Forms),
	drt_message_format('Code simplified to canonic form OK.~n'),
	sformat(Start_KIF_Tag,'~n<KIF>'),
	pretty_print_to_string(Simplified_SUMO_Forms,yes,Translation),
	(theorem_prover_connected ->
	    ask_query_or_make_assertion(Input_String,Simplified_SUMO_Forms,Translation,sentence,assertion,Result);
	    true),
	sformat(End_KIF_Tag,'~n</KIF>~n'),
	sformat(Start_Translation_Warnings_Tag,'~n<translation_warnings>'),
	gather_translation_warnings_for_DRSes(DRSes,List_Of_Translation_Warnings),
	write_numbered_list2(List_Of_Translation_Warnings,Translation_Warnings),
	sformat(End_Translation_Warnings_Tag,'</translation_warnings>'),
	sformat(End_Translation_Tag,'</translation>~n'),
	sformat(Start_Reply_Template_Tag,'~n<reply_template>~n'),
	sformat(End_Reply_Template_Tag,'</reply_template>~n'),
	name(Input,Input_String),
	sformat(Reply_Out,'OK: ~a',[Input]),
	sformat(XML_String,'~a~n~a~a~a~n~a~w~a~n~a~a~a~n~a~n',
		[Start_Translation_Tag,
		 Start_KIF_Tag,Translation,End_KIF_Tag,
		 Start_Translation_Warnings_Tag,Translation_Warnings,End_Translation_Warnings_Tag,
		 Start_Reply_Template_Tag,Reply_Out,End_Reply_Template_Tag,
		 End_Translation_Tag]),
	!.

xml_translate_one_or_more_sentence_with_DRS(Input_String,XML_String) :-
	sformat(Start_Translation_Tag,'~n<translation>'),
	sformat(Start_KIF_Tag,'~n<KIF>'),
	Translation = "",
	sformat(End_KIF_Tag,'~n</KIF>~n'),
	sformat(Start_Translation_Warnings_Tag,'~n<translation_warnings>'),
	(string_list_of_chars(InputCharCodes)->
	    sformat(Translation_Warnings,'~nCould not parse: ~s~n',[Input_String]);
	    sformat(Translation_Warnings,'~nWrong type input, not a string list of ASCII characters: ~w~n',[Input_String])),
	sformat(End_Translation_Warnings_Tag,'</translation_warnings>'),
	sformat(End_Translation_Tag,'</translation>~n'),
	sformat(Start_Reply_Template_Tag,'~n<reply_template>~n'),
	sformat(End_Reply_Template_Tag,'</reply_template>~n'),
	name(Input,Input_String),
	sformat(Reply_Out,'Sorry, did not understand: ~a',[Input]),
	sformat(XML_String,'~a~n~a~a~a~n~a~w~a~n~a~a~a~n~a~n',
		[Start_Translation_Tag,
		 Start_KIF_Tag,Translation,End_KIF_Tag,
		 Start_Translation_Warnings_Tag,Translation_Warnings,End_Translation_Warnings_Tag,
		 Start_Reply_Template_Tag,Reply_Out,End_Reply_Template_Tag,
		 End_Translation_Tag]).
	




