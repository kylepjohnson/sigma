%-------------------------------
% LEXICON
%-------------------------------

% Copyright � 2002 Teknowledge Corporation
% This software released under the GNU Public License <http://www.gnu.org/copyleft/gpl.html>.

% William R. Murray

% General Notes:

%    NUMBER--
%       ACE only handles singular determiners and nouns at present, but
%    the plural form is required for future extensibility. So number is
%    included for nouns, verbs, and determiner lexicon entries. But to
%    simplify the exposition only singular forms are included below and
%    the grammatical rules do not check number since only singular forms
%    are available at present.

%    COMPOUNDS--
%       Typical lexicon entries are single words many entries (e.g., verbs,
%    nouns, adjectives) can be compounds, consisting of two or more words.
%    Examples are 'dry clean', 'credit card', and 'first class'. Note: the current
%    implementation does allow compounds of more than two words. In the
%    case where WORD would be a single word in a lexical entry it is replaced
%    by a list such as [WORD1, WORD2]. E.g., the compound 'dry clean' is specified
%    as [dry,clean] in the verb lexical entry where a simple noun such as 'enter'
%    would be specified as an atom.

:- style_check(-singleton).      % no singletons warnings
:- style_check(-discontiguous).  % allows more creative predicate placement

:-write_herald(', built-in functional words and core lexicon.').

%-------------------------------
% Determiners (Built into ACE)
%-------------------------------

% determiner_in_lexicon(Determiner,Definite_Or_Not,Universal_Or_Not).
% where Definite_Or_Not is one of [definite, indefinite]
% where Universal_Or_Not is one of [universal,existential,definite]

% reminder: ACE only handles singular determiners and nouns at present
% also note that definite determiners that have no antecedents are treated
% as existentials.

determiner_in_lexicon(a,indefinite,existential).
determiner_in_lexicon(an,indefinite,existential).
determiner_in_lexicon(some,indefinite,existential).

determiner_in_lexicon(the,definite,definite).
determiner_in_lexicon(this,definite,definite).

determiner_in_lexicon(every,indefinite,universal).
determiner_in_lexicon(each,indefinite,universal).

%-------------------------------
% Nouns (User Defined)
%-------------------------------

% noun_in_lexicon(Common_noun,Type,Gender,Countability,Number,SUO_concept,Synset_ID).
% see P. 47, ACE manual for specs.

% Type is one of [person,time,object]

% Notes on noun lexicon entries:
%    1. _ used for gender means either masculine or feminine, as it
%    unifies with either, and is considered equivalent to 'neuter',
%    which is not used. So values should be either masculine, feminine,
%    or _ for either or neuter.
%    2. ACE only handles singular determiners and nouns at present, but
%    the plural form is required for future extensibility.
%    3. Current grammar rules only handle compound nouns of exactly
%    two words.

% simple nouns, neuter gender

noun_in_lexicon(card,object,_,count,singular,'BankCard', 104863407).
noun_in_lexicon(bank,object,_,count,singular,'Bank-FinancialOrganization', 106227059).
noun_in_lexicon(teller,person,_,count,singular,'SocialRole',107635368).
noun_in_lexicon(banker,person,_,count,singular,'SocialRole',107100408).
noun_in_lexicon(code,object,_,count,singular,'Text',104790774).        
noun_in_lexicon(train,object,_,count,singular,'TransportationDevice',103528724).
noun_in_lexicon(station,object,_,count,singular,'Building',103209448). % Used word sense of 'train station' here
noun_in_lexicon(slot,object,_,count,singular,'ATMSlot',103355826).
noun_in_lexicon(visitor,person,_,count,singular,'SocialRole',107668613).
noun_in_lexicon(milkman,person,_,count,singular,'SocialRole',107410407).
noun_in_lexicon(machine,object,_,count,singular,'Device',102949521).
noun_in_lexicon(tree,object,_,count,singular,'Plant',109396070).

% example of a mass noun, commented out here as it is in CELT's imported vocabulary:
% noun_in_lexicon(water,object,_,mass,singular,'Liquid',110650211).

% nouns that are roles or otherwise require translations beyond
% simple translations like (instance ?sample Sample) for some example
% class Sample.

noun_in_lexicon(customer,person,_,count,singular,'customer',107197309).
noun_in_lexicon([customer,representative],person,_,count,singular,'customerRepresentative',107543954). % Used word sense of 'salesperson'

% TRANSLATION TEMPLATES

% Translation templates, what are they? Normally, a noun translates to a
% SUMO concept and creates a KIF form such as (instance ?dog Canine) for
% a word 'dog'. However, some words such as 'customer' are not
% represented as nouns in SUMO but instead represented as relations. So
% the word 'customer' is represented as a relation (customer ?customer
% ?salesperson) in SUMO. Note that the additional variable ?salesperson
% may have to be introduced.

% TRANSLATION TEMPLATES VS DOMAIN-SPECIFIC OF-RULES

% However, if a domain-specific 'of' rule has already intercepted the
% relation then the translation template need not be invoked as the 'of'
% rule is more specific and will handle both variables correctly.

% So if we have "John's customer" that will be translated into (customer
% ?customer John) by a domain-specific 'of' rule for 'customer of' and
% we do not need to invoke the translation template for 'customer'.

% translation_template(+Role,+Position,+Suggested_Var_Names, +List_of_SUO_types)
% is interpreted to mean that to say that if some SUO var plays role Role use this template
% with the SUO var in position (starting with 1) Position and constrain
% the other variables (which most also be introduced) to the SUO types
% given.

translation_template(customer,1,
		     ['?customer','?salesperson'],           % Informal documentation for each arg
		     ['CognitiveAgent','CognitiveAgent']).    % Type restrictions
translation_template('customerRepresentative',2,
		     ['?salesperson','?customer','?organization'],
		     ['CognitiveAgent','CognitiveAgent','Organization']).

% stative_verb(+VERB,?VERB_ID,?SUMO_PREDICATE,+TRANSITIVITY,-LAMBDA_EXPRESSION).

% generates special code for stative verbs that have been mapped or should map to SUMO relations
% or to relations that are in extensions of the SUMO, using the
% lambda expression supplied. Note: the first argument is the verb itself, the
% second the WordNet ID of the verb's synset, and the third is the SUMO relation the verb
% maps to. 

% The stative_verb templates are used to map sentences and queries with stative verbs to
% simple relations where the arguments are easily expressed by their grammatical
% positions of subject, direct object, and / or indirect object.

% For example, to translate 'SUBJECT owns DirectObject' to '[possesses, SUBJECT, DirectObject]'
% instead of ...[event,'?event','possesses'],[agent,'?event',SUBJECT],[patient,'?event',DirectObject]...
% we add this stative verb translation template:

% stative_verb(+VERB,VERB_ID,SUMO_PREDICATE,TRANSITIVITY,LAMBDA_EXPRESSION).
stative_verb(own,201509295,possesses,transitive,SUBJECT^DirectObject^[possesses,SUBJECT,DirectObject]).  % map 'own' to 'possesses'
stative_verb(possess,_,_,transitive,SUBJECT^DirectObject^[possesses,SUBJECT,DirectObject]).              % map 'possess' (any word sense, any SUMO concept) to 'possesses'
stative_verb(stay,_,_,intransitive,SUBJECT^[stay,SUBJECT]).                        % map 'stay' (any word sense, any SUMO concept) to 'stay'

% JL: Additional stative verbs


%stative_verb(have,201508689,possesses,transitive,X^Y^[possesses,X,Y]). % map 'have' to 'possesses', as in 'John has a dog.'
%stative_verb(include,201796443,part,transitive,X^Y^[part,Y,X]).        % map 'include' to 'part', as in 'Europe includes France.'       
%stative_verb([belongs,to],201796443,part,transitive,X^Y^[member,X,Y]). % map 'belongs to' to 'member', as in 'France belongs to NATO.'
%stative_verb(contain,_,_,transitive,X^Y^[contains,X,Y]).

stative_verb(author,201168840,_,transitive,X^Y^[authors,X,Y]). 		% author is the oly word in this synset
stative_verb(_,201164896,_,transitive,X^Y^[authors,X,Y]).  		% [write, compose, pen, indite] in this synset
stative_verb(_,201193001,_,transitive,X^Y^[publishes,X,Y]). 		% [print, publish] in this synset
stative_verb(_,201130277,_,transitive,X^Y^[causes,X,Y]).		% [cause, do, make] in this synset

%stative_verb(connect,201789163,_,transitive,X^Y^[connects,X,Y]). 	% connect/3 means to connect a and b with c
                                                                  	% connected/2 is not supported in celt as a passive
                                                                  	
stative_verb(_,200137111,_,transitive,X^Y^[editor,X,Y]).		% [edit, redact] in this synset

% The parser misinterprets 200788109 (use, apply, utilize, utilise, employ) for 'The company employs Bob'. 
% The correct synset should be 201641059 (employ, hire, engage) which matches the meaning of employs 
% in SUMO but is hidden from within celt_verb_lexicon).  To solve this problem, we temporarily ignore 
% the synset and use the verbs instead, until the parse problem is solved.
% stative_verb(employ,201641059,_,transitive,X^Y^[employs,X,Y]).	
stative_verb(employ,_,_,transitive,X^Y^[employs,X,Y]).	
stative_verb(hire,_,_,transitive,X^Y^[employs,X,Y]).	

% The parser misinterprets 'face' in 'the window faces the door' as synset 200551957 (face, confront, face_up).
% SUMO 'faces' means direction with synset 201837332 (front, face, look) (hidden from within celt_verb_lexicon).  
% stative_verb(_,201837332,_,transitive,X^Y^[faces,X,Y]).
stative_verb(face,_,_,transitive,X^Y^[faces,X,Y]).

% inhabits can be mapped into both 201778879 (dwell, reside, inhabit, shack, live, populate, people) and 
% 201811429 (inhabit, occupy).
stative_verb(_,201778879,_,transitive,X^Y^[inhabits,X,Y]).		% [dwell, reside, inhabit, shack, live, populate, people]
stative_verb(_,201811429,_,transitive,X^Y^[inhabits,X,Y]).		% [inhabit, occupy]

stative_verb(inhibit,_,_,transitive,X^Y^[inhibits,X,Y]).
%stative_verb(possess,_,possesses,transitive,X^Y^[possesses,X,Y]).
stative_verb(prevent,_,_,transitive,X^Y^[prevents,X,Y]).

stative_verb(use,_,_,transitive,Y^X^[uses,X,Y]).			% (uses Tool Agent)
stative_verb(penetrate,_,_,transitive,X^Y^[penetrates,X,Y]).
stative_verb(overlap,_,_,transitive,X^Y^[overlapsSpatially,X,Y]).
stative_verb(contain,_,_,transitive,X^Y^[contains,X,Y]).
stative_verb(cross,_,_,transitive,X^Y^[crosses,X,Y]).
stative_verb(fill,_,_,transitive,X^Y^[fills,X,Y]).

% believe has the following 5 senses which all can be mapped to 'believes' in SUMO
% 200460650 (believe)
% 200465761 (think, believe, conceive, consider)
% 200488417 (believe, trust)
% 200461554 (believe)
% 200461366 (believe)
stative_verb(believe,_,_,transitive,X^Y^[believes,X,Y]).

stative_verb(consider,_,_,transitive,X^Y^[considers,X,Y]).
stative_verb(desire,_,_,transitive,X^Y^[desires,X,Y]).
stative_verb(know,_,_,transitive,X^Y^[knows,X,Y]).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% First, mark the stative verbs as 'state', not 'event'
verb_in_lexicon(stretches,stretch,[intransitive, transitive, no],singular,simple,state,'BodyMotion',200019111).
verb_in_lexicon(exists,exist,[intransitive, no, no],singular,simple,state,_,201775163).

stative_verb(exists,_,_,intransitive,SUBJECT^SUBJECT).   

% Note that by omitting parts of the template we can make the translation
% more general. E.g.,
% stative_verb(_,201509295,_,transitive,SUBJECT^DirectObject^[possesses,SUBJECT,DirectObject]).
% would map any transitive verb with synset 201509295 to possesses, not just 'own'.
% But the lambda expression and transitivity (either intransitive, transitive, or
% ditransitive, must always be supplied.

% simple nouns, masculine gender

% Note: these are now commented out as they are present in the CELT common noun lexicon.

% noun_in_lexicon(man,person,masculine,count,singular,['Male','Human','FullyFormed'],107391044).
% noun_in_lexicon(boy,person,masculine,count,singular,['Male','Human'],107389783).
% noun_in_lexicon(male,object,masculine,count,singular,['Male','Human'],100865379).

% simple nouns, feminine gender

% Note: these are now commented out as they are present in the CELT common noun lexicon.

% noun_in_lexicon(woman,person,feminine,count,singular,['Female','Human','FullyFormed'],107684780).
% noun_in_lexicon(girl,person,feminine,count,singular,['Female','Human'],107290496).
% noun_in_lexicon(female,object,feminine,count,singular,['Female','Human'],100865075).

% compound nouns
noun_in_lexicon([credit,card],object,_,count,singular,'CreditCard',109633105).

%-------------------------------
% Pronouns (Built into ACE)
%-------------------------------

% pronoun_in_lexicon(Personal_pronoun,Case,Gender,Number,Type).
% see P. 58, ACE manual for specs.

% Notes on pronoun lexicon entries:
%    1. _ used for gender means either masculine or feminine, as it
%    unifies with either, and is considered equivalent to 'neuter',
%    which is not used. So values should be either masculine, feminine,
%    or _ for either or neuter.



pronoun_in_lexicon(it,_,_,singular,'Object').

pronoun_in_lexicon(he,nominative,masculine,singular,['Human','Male']) :- are_you_assuming_pronouns_human.
pronoun_in_lexicon(she,nominative,feminine,singular,['Human','Female']) :- are_you_assuming_pronouns_human.
pronoun_in_lexicon(him,accusative,masculine,singular,['Human','Male']) :- are_you_assuming_pronouns_human.
pronoun_in_lexicon(her,accusative,feminine,singular,['Human','Female']) :- are_you_assuming_pronouns_human.

pronoun_in_lexicon(he,nominative,masculine,singular,['Male']) :- are_you_not_assuming_pronouns_human.
pronoun_in_lexicon(she,nominative,feminine,singular,['Female']) :- are_you_not_assuming_pronouns_human.
pronoun_in_lexicon(him,accusative,masculine,singular,['Male']) :- are_you_not_assuming_pronouns_human.
pronoun_in_lexicon(her,accusative,feminine,singular,['Female']) :- are_you_not_assuming_pronouns_human.

% For now, as CELT does not even handle plurals except in limited cases, 'they' and 'them' are assumed human.

pronoun_in_lexicon(they,nominative,_,plural,'Human').
pronoun_in_lexicon(them,accusative,_,plural,'Human').

%-------------------------------
% Relative Pronouns (Built into ACE)
%-------------------------------

% relative_pronoun_in_lexicon(Rel,Rel_Type).  
% Rel_Type is one of [person,thing], or _ to refer to both.
% see P. 23, ACE manual for specs.

relative_pronoun_in_lexicon(who,person).   % who refers to people
relative_pronoun_in_lexicon(whom,person).  % whom also refers to people
relative_pronoun_in_lexicon(which,object). % which refers to things
relative_pronoun_in_lexicon(that,person).  % that can refer to people, things, etc.
relative_pronoun_in_lexicon(that,object).  % that can refer to people, things, etc.

%-------------------------------
% Proper Nouns (User Defined)
%-------------------------------

% proper_noun_in_lexicon(+Name,-Type,-Gender,-Number,-SUO_type,-SUO_constant,-Synset_ID).
% where Type is one of [person,time,object] (the same as nouns).

proper_noun_in_lexicon('Jane',person,feminine,singular,['Human','Female'],'Jane-1',empty).
proper_noun_in_lexicon('Karla',person,feminine,singular,['Human','Female'],'Karla-1',empty).
proper_noun_in_lexicon('SimpleMat',object,_,singular,'Artifact','SimpleMat-1',empty).
proper_noun_in_lexicon(['Mr','Miller'],person,masculine,singular,['Human','Male','FullyFormed'],'MrMiller',empty).
proper_noun_in_lexicon(['The','New','York','Times'],object,_,singular,'Artifact','TheNewYorkTimes',empty).

% 50 most common names from http://www.lifesmith.com/comnames.html, also see http://www.behindthename.com/top.html

% Common names of males
proper_noun_in_lexicon('James',person,masculine,singular,['Human','Male'],'James-1',empty).
proper_noun_in_lexicon('Jim',person,masculine,singular,['Human','Male'],'James-1',empty).

proper_noun_in_lexicon('Christopher',person,masculine,singular,['Human','Male'],'Christopher-1',empty).
proper_noun_in_lexicon('Chris',person,masculine,singular,['Human','Male'],'Christopher-1',empty).

proper_noun_in_lexicon('Ronald',person,masculine,singular,['Human','Male'],'Ronald-1',empty).
proper_noun_in_lexicon('Ron',person,masculine,singular,['Human','Male'],'Ronald-1',empty).

proper_noun_in_lexicon('John',person,masculine,singular,['Human','Male'],'John-1',empty).

proper_noun_in_lexicon('Daniel',person,masculine,singular,['Human','Male'],'Daniel-1',empty).
proper_noun_in_lexicon('Dan',person,masculine,singular,['Human','Male'],'Daniel-1',empty).

proper_noun_in_lexicon('Anthony',person,masculine,singular,['Human','Male'],'Anthony-1',empty).
proper_noun_in_lexicon('Tony',person,masculine,singular,['Human','Male'],'Anthony-1',empty).

proper_noun_in_lexicon('Robert',person,masculine,singular,['Human','Male'],'Robert-1',empty).
proper_noun_in_lexicon('Bob',person,masculine,singular,['Human','Male'],'Robert-1',empty).

proper_noun_in_lexicon('Paul',person,masculine,singular,['Human','Male'],'Paul-1',empty).

proper_noun_in_lexicon('Kevin',person,masculine,singular,['Human','Male'],'Kevin-1',empty).

proper_noun_in_lexicon('Michael',person,masculine,singular,['Human','Male'],'Michael-1',empty).
proper_noun_in_lexicon('Mike',person,masculine,singular,['Human','Male'],'Michael-1',empty).

proper_noun_in_lexicon('Mark',person,masculine,singular,['Human','Male'],'Mark-1',empty).

proper_noun_in_lexicon('Jason',person,masculine,singular,['Human','Male'],'Jason-1',empty).

proper_noun_in_lexicon('William',person,masculine,singular,['Human','Male'],'William-1',empty).
proper_noun_in_lexicon('Bill',person,masculine,singular,['Human','Male'],'William-1',empty).

proper_noun_in_lexicon('Donald',person,masculine,singular,['Human','Male'],'Donald-1',empty).
proper_noun_in_lexicon('Don',person,masculine,singular,['Human','Male'],'Donald-1',empty).

proper_noun_in_lexicon('Jeff',person,masculine,singular,['Human','Male'],'Jeff-1',empty).

proper_noun_in_lexicon('David',person,masculine,singular,['Human','Male'],'David-1',empty).
proper_noun_in_lexicon('Dave',person,masculine,singular,['Human','Male'],'David-1',empty).

proper_noun_in_lexicon('George',person,masculine,singular,['Human','Male'],'George-1',empty).

proper_noun_in_lexicon('Richard',person,masculine,singular,['Human','Male'],'Richard-1',empty).
proper_noun_in_lexicon('Dick',person,masculine,singular,['Human','Male'],'Richard-1',empty).

proper_noun_in_lexicon('Kenneth',person,masculine,singular,['Human','Male'],'Kenneth-1',empty).
proper_noun_in_lexicon('Ken',person,masculine,singular,['Human','Male'],'Kenneth-1',empty).

proper_noun_in_lexicon('Charles',person,masculine,singular,['Human','Male'],'Charles-1',empty).
proper_noun_in_lexicon('Charlie',person,masculine,singular,['Human','Male'],'Charles-1',empty).

proper_noun_in_lexicon('Steven',person,masculine,singular,['Human','Male'],'Steven-1',empty).
proper_noun_in_lexicon('Steve',person,masculine,singular,['Human','Male'],'Steven-1',empty).

proper_noun_in_lexicon('Joseph',person,masculine,singular,['Human','Male'],'Joseph-1',empty).
proper_noun_in_lexicon('Joe',person,masculine,singular,['Human','Male'],'Joseph-1',empty).

proper_noun_in_lexicon('Edward',person,masculine,singular,['Human','Male'],'Edward-1',empty).
proper_noun_in_lexicon('Ed',person,masculine,singular,['Human','Male'],'Edward-1',empty).

proper_noun_in_lexicon('Thomas',person,masculine,singular,['Human','Male'],'Thomas-1',empty).
proper_noun_in_lexicon('Tom',person,masculine,singular,['Human','Male'],'Tom-1',empty).

proper_noun_in_lexicon('Brian',person,masculine,singular,['Human','Male'],'Brian-1',empty).
proper_noun_in_lexicon('Rick',person,masculine,singular,['Human','Male'],'Brian-1',empty).

% Common names of females

proper_noun_in_lexicon('Mary',person,feminine,singular,['Human','Female'],'Mary-1',empty).

proper_noun_in_lexicon('Lisa',person,feminine,singular,['Human','Female'],'Lisa-1',empty).

proper_noun_in_lexicon('Michelle',person,feminine,singular,['Human','Female'],'Michelle-1',empty).

proper_noun_in_lexicon('Patricia',person,feminine,singular,['Human','Female'],'Patricia-1',empty).
proper_noun_in_lexicon('Pat',person,feminine,singular,['Human','Female'],'Patricia-1',empty).

proper_noun_in_lexicon('Nancy',person,feminine,singular,['Human','Female'],'Nancy-1',empty).

proper_noun_in_lexicon('Laura',person,feminine,singular,['Human','Female'],'Laura-1',empty).

proper_noun_in_lexicon('Linda',person,feminine,singular,['Human','Female'],'Linda-1',empty).

proper_noun_in_lexicon('Karen',person,feminine,singular,['Human','Female'],'Karen-1',empty).

proper_noun_in_lexicon('Sarah',person,feminine,singular,['Human','Female'],'Sarah-1',empty).
proper_noun_in_lexicon('Sara',person,feminine,singular,['Human','Female'],'Sarah-1',empty).

proper_noun_in_lexicon('Barbara',person,feminine,singular,['Human','Female'],'Barbara-1',empty).

proper_noun_in_lexicon('Betty',person,feminine,singular,['Human','Female'],'Betty-1',empty).

proper_noun_in_lexicon('Kimberly',person,feminine,singular,['Human','Female'],'Kimberly-1',empty).
proper_noun_in_lexicon('Kim',person,feminine,singular,['Human','Female'],'Kimberly-1',empty).

proper_noun_in_lexicon('Elizabeth',person,feminine,singular,['Human','Female'],'Elizabeth-1',empty).
proper_noun_in_lexicon('Liz',person,feminine,singular,['Human','Female'],'Elizabeth-1',empty).

proper_noun_in_lexicon('Helen',person,feminine,singular,['Human','Female'],'Helen-1',empty).

proper_noun_in_lexicon('Deborah',person,feminine,singular,['Human','Female'],'Deborah-1',empty).
proper_noun_in_lexicon('Debbie',person,feminine,singular,['Human','Female'],'Deborah-1',empty).

proper_noun_in_lexicon('Jennifer',person,feminine,singular,['Human','Female'],'Jennifer-1',empty).
proper_noun_in_lexicon('Jenny',person,feminine,singular,['Human','Female'],'Jennifer-1',empty).

proper_noun_in_lexicon('Sandra',person,feminine,singular,['Human','Female'],'Sandra-1',empty).

proper_noun_in_lexicon('Maria',person,feminine,singular,['Human','Female'],'Maria-1',empty).

proper_noun_in_lexicon('Donna',person,feminine,singular,['Human','Female'],'Donna-1',empty).

proper_noun_in_lexicon('Susan',person,feminine,singular,['Human','Female'],'Susan-1',empty).

proper_noun_in_lexicon('Carol',person,feminine,singular,['Human','Female'],'Carol-1',empty).

proper_noun_in_lexicon('Margaret',person,feminine,singular,['Human','Female'],'Margaret-1',empty).

proper_noun_in_lexicon('Ruth',person,feminine,singular,['Human','Female'],'Ruth-1',empty).

proper_noun_in_lexicon('Dorothy',person,feminine,singular,['Human','Female'],'Dorothy-1',empty).

proper_noun_in_lexicon('Sharon',person,feminine,singular,['Human','Female'],'Sharon-1',empty).

proper_noun_in_lexicon('Jill',person,feminine,singular,['Human','Female'],'Jill-1',empty).

proper_noun_in_lexicon('Monday',time,_,singular,'Day','Monday',110882888).
proper_noun_in_lexicon('Tuesday',time,_,singular,'Day','Tuesday',110883014).
proper_noun_in_lexicon('Wednesday',time,_,singular,'Day','Wednesday',110883142).
proper_noun_in_lexicon('Thursday',time,_,singular,'Day','Thursday',110883253).
proper_noun_in_lexicon('Friday',time,_,singular,'Day','Friday',110883362).
proper_noun_in_lexicon('Saturday',time,_,singular,'Day','Saturday',110883469).
proper_noun_in_lexicon('Sunday',time,_,singular,'Day','Sunday',110883776).

proper_noun_in_lexicon('January',time,_,singular,'Month','January',110922756).
proper_noun_in_lexicon('February',time,_,singular,'Month','February',110923216).
proper_noun_in_lexicon('March',time,_,singular,'Month','March',110923619).
proper_noun_in_lexicon('April',time,_,singular,'Month','April',110923938).
proper_noun_in_lexicon('May',time,_,singular,'Month','May',110924252).
proper_noun_in_lexicon('June',time,_,singular,'Month','June',110924593).
proper_noun_in_lexicon('July',time,_,singular,'Month','July',110924973).
proper_noun_in_lexicon('August',time,_,singular,'Month','August',110925280).
proper_noun_in_lexicon('September',time,_,singular,'Month','September',110925564).
proper_noun_in_lexicon('October',time,_,singular,'Month','October',110925921).
proper_noun_in_lexicon('November',time,_,singular,'Month','November',110926231).
proper_noun_in_lexicon('December',time,_,singular,'Month','December',110926618).

% these are here temporarily to allow them to be referred to without determiners:
% e.g., 'he arrives at midnight.'
proper_noun_in_lexicon(midnight,time,_,singular,'TimeMeasure','Midnight',110887026).
proper_noun_in_lexicon(noon,time,_,singular,'TimeMeasure','NoonTime',110884479).


%-------------------------------
% Adjectives (User Defined)
%-------------------------------

% adjective_in_lexicon(Adjective,Root,Kind,Grade,SUO_concept)

% Note: SUO_concept is a lambda expression for two-place adjectives.

% Kind is one of [normal, two_place]
% Grade is one of [positive,comparative,superlative]
% ...note: use positive if the adjective is normally ungraded.

% graded adjectives:
adjective_in_lexicon(large,large,normal,positive,'Large'). % Word Net Synset 01328712
adjective_in_lexicon(larger,large,normal,comparative,'Large'). % Word Net Synset 01328712
adjective_in_lexicon(largest,large,normal,superlative,'Large'). % Word Net Synset 01328712

adjective_in_lexicon(small,small,normal,positive,'Small'). % Word Net Synset 01336443
adjective_in_lexicon(smaller,small,normal,comparative,'Small'). % Word Net Synset 01336443
adjective_in_lexicon(smallest,small,normal,superlative,'Small'). % Word Net Synset 01336443

adjective_in_lexicon(old,old,normal,positive,'Old'). % Word Net Synset 03854196
adjective_in_lexicon(older,old,normal,comparative,'Old'). % Word Net Synset 03854196
adjective_in_lexicon(oldest,old,normal,superlative,'Old'). % Word Net Synset 03854196

adjective_in_lexicon(new,new,normal,positive,'New'). % Word Net Synset 03855074
adjective_in_lexicon(newer,new,normal,comparative,'New'). % Word Net Synset 03855074
adjective_in_lexicon(newest,new,normal,superlative,'New'). % Word Net Synset 03855074

adjective_in_lexicon(hungry,hungry,normal,positive,'Hungry'). % Word Net Synset 01216853
adjective_in_lexicon(hungrier,hungry,normal,comparative,'Hungry'). % Word Net Synset 01216853
adjective_in_lexicon(hungriest,hungry,normal,superlative,'Hungry'). % Word Net Synset 01216853

adjective_in_lexicon(thirsty,thirsty,normal,positive,'Thirsty'). % Word Net Synset 01217685
adjective_in_lexicon(thirstier,thirsty,normal,comparative,'Thirsty'). % Word Net Synset 01217685
adjective_in_lexicon(thirstiest,thirst,normal,superlative,'Thirsty'). % Word Net Synset 01217685

adjective_in_lexicon(rich,rich,normal,positive,'Rich'). % Word Net Synset 01950464
adjective_in_lexicon(richer,rich,normal,comparative,'Rich'). % Word Net Synset 01950464
adjective_in_lexicon(richest,rich,normal,superlative,'Rich'). % Word Net Synset 01950464

adjective_in_lexicon(fast,fast,normal,positive,'Fast'). % Word Net Synset 00212796
adjective_in_lexicon(faster,fast,normal,comparative,'Fast'). % Word Net Synset 00212796
adjective_in_lexicon(fastest,fast,normal,superlative,'Fast'). % Word Net Synset 00212796

adjective_in_lexicon(expensive,expensive,normal,positive,'Expensive'). % Word Net Synset 04009070
adjective_in_lexicon([more,expensive],expensive,normal,comparative,'Expensive'). % Word Net Synset 04009070
adjective_in_lexicon([most,expensive],expensive,normal,superlative,'Expensive'). % Word Net Synset 04009070

adjective_in_lexicon(solid,solid,normal,positive,'Solid').
adjective_in_lexicon(liquid,liquid,normal,positive,'Liquid').
adjective_in_lexicon(gas,gas,normal,positive,'Gas').
adjective_in_lexicon(sweet,sweet,normal,positive,'Sweet').
adjective_in_lexicon(bitter,bitter,normal,positive,'Bitter').

adjective_in_lexicon(red,red,normal,positive,'Red').
adjective_in_lexicon(green,green,normal,positive,'Green').
adjective_in_lexicon(blue,blue,normal,positive,'Blue').
adjective_in_lexicon(yellow,yellow,normal,positive,'Yellow').

adjective_in_lexicon(open,open,normal,positive,'Open'). % Word Net Synset 00037427
adjective_in_lexicon(fillable,fillable,normal,positive,'Fillable').
adjective_in_lexicon(pliable,pliable,normal,positive,'Pliable').
adjective_in_lexicon(rigid,rigid,normal,positive,'Rigid').

adjective_in_lexicon(smooth,smooth,normal,positive,'Smooth').
adjective_in_lexicon(rough,rough,normal,positive,'Rough').

adjective_in_lexicon(dry,dry,normal,positive,'Dry').
adjective_in_lexicon(anhydrous,anhydrous,normal,positive,'Anhydrous').
adjective_in_lexicon(damp,damp,normal,positive,'Damp').
adjective_in_lexicon(wet,wet,normal,positive,'Wet').

adjective_in_lexicon(fragile,fragile,normal,positive,'Fragile').
adjective_in_lexicon(unbreakable,unbreakable,normal,positive,'Unbreakable').

adjective_in_lexicon(living,living,normal,positive,'Living').
adjective_in_lexicon(dead,dead,normal,positive,'Dead').

adjective_in_lexicon(larval,larval,normal,positive,'Larval').
adjective_in_lexicon(embryonic,embryonic,normal,positive,'Embryonic').
adjective_in_lexicon(fetal,fetal,normal,positive,'Fetal').

adjective_in_lexicon(aggressive,aggressive,normal,positive,'Aggressive').
adjective_in_lexicon(docile,docile,normal,positive,'Docile').

adjective_in_lexicon(asleep,asleep,normal,positive,'Asleep').
adjective_in_lexicon(unconscious,unconscious,normal,positive,'Unconscious').
adjective_in_lexicon(awake,awake,normal,positive,'Awake').

% compound adjectives:
adjective_in_lexicon([first,class],first_class,normal,positive,'First_class'). % Word Net Synset 03718753

% two-place adjectives (take a prepositional complement, the preposition is included here)
% Note: SUO_concept is a lambda expression for two-place adjectives.
adjective_in_lexicon([identical,to],identical,two_place,ungraded,X^Y^[equal,X,Y]).
adjective_in_lexicon([compatible,with],compatible_with,two_place,ungraded,X^Y^[compatible,X,Y]).
adjective_in_lexicon([greater,than],greater_than,two_place,ungraded,X^Y^[greaterThan,X,Y]).
adjective_in_lexicon([less,than],less_than,two_place,ungraded,X^Y^[lessThan,X,Y]).
adjective_in_lexicon([different,from],different_from,two_place,ungraded,X^Y^[not,[equal,X,Y]]).

% ungraded adjectives (note: use positive for the grade)
adjective_in_lexicon(valid,valid,normal,positive,'Valid'). % Word Net Synset 00099890
adjective_in_lexicon(invalid,invalid,normal,positive,'Incorrect'). % Word Net Synset 03838242

% Notes on adjective entries:
%    1. ACE does not allow 'that' as the preposition for
%    two-place adjectives, see p. 52 for explanation.

%-------------------------------
% Prepositions (Built into ACE)
%-------------------------------

% preposition_in_lexicon(Preposition,Modification_type,Noun_type,SUO_concept).
% see P. 54, ACE manual for specs. Note that 'at', 'on', and 'in' can apply to
% either locations or times and if the object noun is of type 'time' then the
% temporal interpretation of the adverb is taken.

% Noun_type is one of [person,time,object]
% Modification_type is one of [location, origin, direction, time, start, end, duration, instrument, comitative]

% The interpretation of some of these prepositions may depend on whether the verb is stative
% or not or the verb itself. For example, for 'he lies on the floor' the preposition 'on' should
% be either 'located' or 'oriented' on the floor. For a non-stative verb such as in 'he throws the
% ball on the floor' the preposition 'on' is 'destination'. Eventually we may need a small rule system
% here rather than these defaults.

% Here are the old definitions, which seem more correct for stative verbs only:

% preposition_in_lexicon(at,location,object,'located').               % e.g., 'at the house'
% preposition_in_lexicon(on,location,object,                          % e.g., 'on the floor'
% 		       Event^Object^[orientation,Event,Object,'On']).
% preposition_in_lexicon(beneath,location,object,                     % e.g., 'beneath the floor'
% 		       Event^Object^[orientation,Event,Object,'Below']).
% preposition_in_lexicon(in,location,object,'located').               % e.g., 'in the house'
% preposition_in_lexicon(to,location,object,'located').               % e.g., 'to the house'

% These are now applied for copula 'be' :

determine_prepositional_relation_from_preposition_in_lexicon(be,at,location,object,'located') :- !.
determine_prepositional_relation_from_preposition_in_lexicon(be,on,location,object,Event^Object^[orientation,Event,Object,'On']) :- !.
determine_prepositional_relation_from_preposition_in_lexicon(be,in,location,object,'located') :- !.
determine_prepositional_relation_from_preposition_in_lexicon(be,inside,location,object,'located') :- !.

% and the new definitions below apply for all other verbs:

% determine_prepositional_relation_from_preposition_in_lexicon(+ACT,+Preposition,-Modification_type,-Noun_type,-SUO_concept)
determine_prepositional_relation_from_preposition_in_lexicon(ACT,Preposition,Modification_type,Noun_type,SUO_concept) :-
	preposition_in_lexicon(Preposition,Modification_type,Noun_type,SUO_concept).

% Here are the new definitions, which seem more correct for non-stative verbs only:

preposition_in_lexicon(at,location,object,'destination').           % e.g., 'at the house'
preposition_in_lexicon(on,location,object,'destination').           % e.g., 'on the floor'
preposition_in_lexicon(beneath,location,object,'destination').      % e.g., 'beneath the floor'
preposition_in_lexicon(in,location,object,'destination').           % e.g., 'in the house'
preposition_in_lexicon(to,location,object,'destination').           % e.g., 'to the house'

preposition_in_lexicon(to,location,time,Event^Time^[equal,Time,['EndFn',Event]]).    % e.g., 'to the opening' (e.g., 'He waits to the opening.') like until.

preposition_in_lexicon(at,time,time,'overlapsTemporally').          % e.g., 'at 9 AM'
preposition_in_lexicon(on,time,time,'overlapsTemporally').          % e.g., 'on Monday'
preposition_in_lexicon(in,time,time,'overlapsTemporally').          % e.g., 'in an hour'

preposition_in_lexicon(for,direction,person,'destination').         % e.g., 'for John'
preposition_in_lexicon(for,duration,time,'duration').               % e.g., 'for one hour'

preposition_in_lexicon(from,origin,object,'origin').                % e.g., 'from the station'
preposition_in_lexicon(from,start,time,Event^Time^[equal,Time,['BeginFn',Event]]).                  % e.g., 'from noon'

preposition_in_lexicon(into,direction,object,'destination').        % e.g., 'into the office'

preposition_in_lexicon(through,direction,object,'traverses').       % e.g., 'through the door'
preposition_in_lexicon(through,duration,time,'overlapsTemporally'). % e.g., 'through Monday'
preposition_in_lexicon(during,duration,time,'overlapsTemporally'). % e.g., 'during Monday'
preposition_in_lexicon(throughout,duration,time,'overlapsTemporally'). % e.g., 'throughout Monday'

% preposition_in_lexicon(until,end,time,'EndFn').                     % e.g., 'until Tuesday'
preposition_in_lexicon(until,end,time,Event^Time^[equal,Time,['EndFn',Event]]).                     % e.g., 'until Tuesday'

preposition_in_lexicon(with,instrument,object,'instrument').        % e.g., 'with a key'
preposition_in_lexicon(with,comitative,person,                      % e.g., 'with a policeman',
		       Event^Person^[agent,Event,Person]).          %  in this case person is an additional agent of the event

% Examples of additional prepositions added with 2-arg Lambda expressions for Event and Object
% for additional adverbs taking an object of CELT type 'object'.

preposition_in_lexicon(across,direction,object,Event^Object^[traverses,Event,Object]).
preposition_in_lexicon(toward,location,object,Event^Object^[direction,Event,Object]).
preposition_in_lexicon(inside,location,object,Event^Object^[exactlyLocated,Event,Object]).
preposition_in_lexicon(outside,location,object,Event^Object^[not,[located,Event,Object]]).
preposition_in_lexicon(within,location,object,Event^Object^[located,Event,Object]).
preposition_in_lexicon(around,direction,object,Event^Object^[orientation,Event,Object,'Near']).
preposition_in_lexicon(above,location,object,Event^Object^[orientation,Event,Object,'Above']).
preposition_in_lexicon(over,location,object,Event^Object^[orientation,Event,Object,'Above']).
preposition_in_lexicon(below,location,object,Event^Object^[orientation,Event,Object,'Below']).
preposition_in_lexicon(under,location,object,Event^Object^[orientation,Event,Object,'Below']).
preposition_in_lexicon(atop,location,object,Event^Object^[orientation,Event,Object,'On']).

% Examples of additional prepositions added with 2-arg Lambda expressions for Event and Person
% for additional adverbs taking an object of CELT type 'person'.
preposition_in_lexicon(inside,direction,person,Event^Person^[direction,Event,Person]).
preposition_in_lexicon(outside,direction,person,Event^Person^[direction,Event,Person]).
preposition_in_lexicon(through,direction,person,Event^Person^[penetrates,Event,Person]).

% Examples of additional prepositions added with 2-arg Lambda expressions for Event and Time
% for additional adverbs taking an object of CELT type 'time'.
preposition_in_lexicon(before,direction,time,Event^Time^[lessThan,['BeginFn',Event],['BeginFn',Time]]).
preposition_in_lexicon(after,direction,time,Event^Time^[greaterThan,['EndFn',Event],['EndFn',Time]]).

% Note: from...to is not yet handled, use from...until in the meantime as a workaround
temporal_expression_in_lexicon(from,to,start,end,'start_time','end_time'). % e.g., 'from 10 to 12', must occur in from...to

% special prepositions: 'of' and 'to' are built into grammatical rules for noun and verb modifiers,
% so we do NOT need any additional entries for them like the following:

% preposition_in_lexicon(of,noun_attribute).            % special, only preposition that can be used as a noun modifier
% preposition_in_lexicon(to,ditransitive_complement).   % special, only preposition used with indirect objects in ACE

% Notes on preposition lexicon entries:
%    1. 'to' as modification type 'end' should
%    only occur in a 'from...to' prepositional phrase.
%    Currently this is not checked for to simplify the grammar.

%-------------------------------
% Verbs (User Defined)
%-------------------------------

% verb_in_lexicon(Verb,Root,Transitivity,Number,Kind_of_verb,Event_or_state,SUO_concept,Synset_ID).
% Kind_of_verb is one of [simple,compound,phrasal,prepositional].
% Event_or_state is one of [event,state], state for stative verbs.

% Note: The copula verb 'be' is handled directly in the grammar rules and has no entry here.

% Simple verbs:         verb_in_lexicon(Verb,Root,Transitivity,Number,simple).
% Compound verbs:       verb_in_lexicon([Word1,Word2],Root,Transitivity,Number,compound).
% Phrasal verbs:        verb_in_lexicon([Verb,Prep],Root,Transitivity,Number,phrasal).
% Prepositional verbs:  verb_in_lexicon([Verb,Prep],Root,Transitivity,Number,prepositional).

% simple verbs
% ...intransitive
% Intransitivity is a term that describes a verb or clause that is unable to take a direct object.
verb_in_lexicon(stays,stay,[intransitive,no,no],singular,simple,state,'Motion',200078446).
verb_in_lexicon(decomposes,decompose,[intransitive,no,no],singular,simple,event,'ChemicalDecomposition',200143411).
verb_in_lexicon(turns,turn,[intransitive,no,no],singular,simple,event,'DirectionChange',2013101287).
verb_in_lexicon(floats,float,[intransitive,no,no],singular,simple,event,'Swimming',201299337).
verb_in_lexicon(works,work,[intransitive,no,no],singular,simple,event,'Works',201643531).
verb_in_lexicon(runs,run,[intransitive, no, no],singular,simple,event,'Walking',201314495).
verb_in_lexicon(comes,come,[intransitive,no,no],singular,simple,event,'Comes',201262658).
verb_in_lexicon(stop,stops,[intransitive,no,no],singular,simple,event,'Stops',201270990).

% ...transitive
% A transitive verb is a verb that takes a direct object.
verb_in_lexicon(enters,enter,[no,transitive,no],singular,simple,event,'Motion',201376901).
verb_in_lexicon(beats,beat,[no,transitive,no],singular,simple,event,'Impacting',200958408). 
verb_in_lexicon(inserts,insert,[no,transitive,no],singular,simple,event,'Putting',200974668).
verb_in_lexicon(owns,own,[no,transitive,no],singular,simple,state,'possesses',201509295).

% ...transitive and stative verbs...

verb_in_lexicon(has,have,[no, transitive, no],singular,simple,state,possesses,201508689).    
verb_in_lexicon(includes,include,[no, transitive, no],singular,simple,state,part,201796443).

% Note: also see discussion of stative verb templates earlier in this file.
stative_verb(have,201508689,possesses,transitive,X^Y^[possesses,X,Y]). % map 'have' to 'possesses', as in 'John has a dog.'
stative_verb(include,201796443,part,transitive,X^Y^[part,Y,X]).        % map 'include' to 'part', as in 'Europe includes France.'

% ...ditransitive
% Ditransitivity is a term which describes a verb or clause which takes two objects.
verb_in_lexicon(gives,give,[no,no,ditransitive],singular,simple,event,'Giving',201583087).
verb_in_lexicon(puts,put,[no,no,ditransitive],singular,simple,event,'Putting',201026409).
verb_in_lexicon(attaches,attach,[no,no,ditransitive],singular,simple,event,'Attaching',200885494).
verb_in_lexicon(detaches,detach,[no,no,ditransitive],singular,simple,event,'Detaching',200887219).
verb_in_lexicon(unties,untie,[no,no,ditransitive],singular,simple,event,'Untying',200877495).
verb_in_lexicon(separates,sepate,[no,no,ditransitive],singular,simple,event,'Separating',201788872).
verb_in_lexicon(combines,combine,[no,no,ditransitive],singular,simple,event,'Combining',200133085).

% compound verbs
verb_in_lexicon([dry,cleans],[dry,clean],[no,transitive,no],singular,compound,event,'Cleaning',201056234).

% phrasal verbs (see P. 49)
verb_in_lexicon([hands,out],[hand,out],[no,transitive,no],singular,phrasal,event,'Giving',201507640).
verb_in_lexicon([fills,out],[fill,out],[no,transitive,no],singular,phrasal,event,'Writing',200690164).
verb_in_lexicon([takes,off],[take,off],[no,transitive,no],singular,phrasal,event,'Removing',201095514).

% prepositional verbs (see P.49)
verb_in_lexicon([gives,to],[give,to],[no,no,ditransitive],singular,prepositional,event,'Giving',201505951).
verb_in_lexicon([calls,for],[call,for],[no,transitive,no],singular,prepositional,event,'Communication',200510998).
verb_in_lexicon([calls,on],[call,for],[no,transitive,no],singular,prepositional,event,'Communication',200539812).

verb_in_lexicon([belongs, to],[belong, to],[no, transitive, no],singular,prepositional,state,part,201859471).
stative_verb([belongs,to],201796443,part,transitive,X^Y^[member,X,Y]).      % map 'belongs to' to 'member', as in 'France belongs to NATO.'

verb_in_lexicon([is,at],[be,at],[no, transitive, no],singular,prepositional,state,located,201811792).
stative_verb([is,at],201811792,located,transitive,X^Y^[located,X,Y]).      % 'is' referring to location.

% Notes on verb lexicon entries:
%    1. ACE only handles singular determiners and nouns at present, but
%    the plural form of nouns and verbs is required for future extensibility.
%    2. Compound verbs always have two words (e.g., 'dry clean') in the
%    current implementation.

%-------------------------------
% Adverbs (User Defined)
%-------------------------------

% adverb_in_lexicon(Adverb,Modification_type,Sigma_Concept).
% see P. 53 & p.56 ACE manual for specs.
% Modification_type is one of ...
%   [location,origin,direction,time,start,end,duration,frequency,instrument,manner,comitative]
% (see p. 57).

% Notes on adverb lexicon entries:
%    1. Many kinds of adverbs are disallowed
% in ACE, e.g., adverbs of degree ('barely'),
% see P. 54 for rationale.

adverb_in_lexicon(underground,location,'Underground'). % Word Net Synset 03560180
adverb_in_lexicon(forward,direction,'Front'). % Word Net Synset 02724935
adverb_in_lexicon(now,time,'Presently'). % Word Net Synset 04776839
adverb_in_lexicon(permanently,duration,'Permanently'). % Word Net Synset 03944434
adverb_in_lexicon(daily,frequency,'Daily'). %need to get other sense here, this one is for the daily news.. Word Net Synset 04738867
adverb_in_lexicon(correctly,manner,'Correctly'). % Word Net Synset 03836923
adverb_in_lexicon(manually,manner,'Manually'). % Word Net Synset 00410579
adverb_in_lexicon(slowly,manner,'Slowly'). % Word Net Synset 03951223
adverb_in_lexicon(punctually,manner,'Punctually'). % Word Net Synset 03940380
